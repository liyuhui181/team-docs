"""
ECM50-A07 主程序（集成 miIO + MQTT）

工作流程：
1. 连接 WiFi
2. 与米家智能插座握手（miIO 协议）
3. 连接 MQTT broker
4. 主循环：每 5 秒读取插座数据 → 串口打印 → 发布到 MQTT
5. 同时监听 MQTT cmd 主题，处理云端指令（读数据/控制开关/控制指示灯）

上电自启: MicroPython 自动执行 boot.py -> main.py
断电恢复: 任何关键步骤失败后自动重试，超过限制则重启设备
"""

import time
import network
import gc
import json
import machine
from umqtt.robust import MQTTClient

import umiiio


# ===== 米家智能插座3 (cuco.plug.v3) 属性映射 =====
SOCKET_PROPERTIES = [
    ("switch", 2, 1, "Switch", "bool"),
    ("fault", 2, 3, "Fault", "uint8"),
    ("power", 11, 2, "Power", "float"),
    ("power_consumed", 11, 1, "Energy", "uint16(0.01kWh)"),
    ("on_off_count", 12, 1, "Count", "uint8"),
    ("temperature", 12, 2, "Temp", "uint8"),
    ("indicator_light", 13, 1, "LED", "bool"),
]


def connect_wifi(ssid, password, timeout=20, retries=3):
    """连接 WiFi，失败自动重试，返回 IP 或 None"""
    sta = network.WLAN(network.STA_IF)

    for attempt in range(retries):
        if not sta.active():
            sta.active(True)
            time.sleep(2)
        if sta.isconnected():
            return sta.ifconfig()[0]

        print("[WiFi] connecting: %s (attempt %d/%d)" % (ssid, attempt + 1, retries))
        sta.connect(ssid, password)

        t0 = time.time()
        while not sta.isconnected():
            if time.time() - t0 > timeout:
                print("[WiFi] timeout")
                break
            time.sleep(0.5)

        if sta.isconnected():
            ifconfig = sta.ifconfig()
            print("[WiFi] OK, IP=%s" % ifconfig[0])
            return ifconfig[0]

        # 断开重试
        sta.active(False)
        time.sleep(1)

    print("[WiFi] all retries failed")
    return None


def format_value(key, value):
    """格式化属性值用于打印"""
    if value is None:
        return "N/A"
    if isinstance(value, bool):
        return "ON" if value else "OFF"
    if key == "power_consumed" and isinstance(value, (int, float)):
        return "%.3f kWh" % (value / 100.0)
    if isinstance(value, float):
        return "%.2f" % value
    return str(value)


def read_all_props(dev):
    """批量读取所有属性，返回 dict（key -> value）"""
    req = [{"siid": p[1], "piid": p[2]} for p in SOCKET_PROPERTIES]
    results = dev.get_properties(req)
    out = {}
    if isinstance(results, list):
        for i, (key, siid, piid, name, _type) in enumerate(SOCKET_PROPERTIES):
            value = None
            if i < len(results):
                item = results[i]
                if isinstance(item, dict) and item.get("code", -1) == 0:
                    value = item.get("value")
            out[key] = value
    return out


def build_payload(data, dev_id, seq):
    """构造 MQTT 上报 JSON payload"""
    ts = time.time()
    payload = {
        "device_id": dev_id,
        "seq": seq,
        "ts": int(ts),
        "switch": data.get("switch"),
        "fault": data.get("fault"),
        "power": data.get("power"),
        "energy_kwh": round(data.get("power_consumed", 0) / 100.0, 3)
                       if data.get("power_consumed") is not None else None,
        "on_off_count": data.get("on_off_count"),
        "temperature": data.get("temperature"),
        "indicator_light": data.get("indicator_light"),
    }
    return payload


def print_data(data):
    """串口打印数据表"""
    print("=" * 50)
    print("  cuco.plug.v3 - Realtime (via ECM50-A07)")
    print("=" * 50)
    for key, siid, piid, name, _type in SOCKET_PROPERTIES:
        value = data.get(key)
        print("  %-8s : %s" % (name, format_value(key, value)))
    print("=" * 50)


def handle_cmd(cmd_msg, dev):
    """处理来自云端的指令"""
    try:
        cmd = cmd_msg.get("cmd")
    except Exception:
        return {"error": "invalid cmd format"}

    if cmd == "read_power":
        return {"power": dev.get_prop(11, 2)}
    elif cmd == "read_all":
        return build_payload(read_all_props(dev), "resp", 0)
    elif cmd == "set_switch":
        val = bool(cmd_msg.get("value"))
        ok = dev.set_prop(2, 1, val)
        return {"ok": ok, "switch": val}
    elif cmd == "set_led":
        val = bool(cmd_msg.get("value"))
        ok = dev.set_prop(13, 1, val)
        return {"ok": ok, "led": val}
    else:
        return {"error": "unknown cmd: %s" % cmd}


def miio_handshake(plug_ip, plug_token, retries=3):
    """miIO 握手，失败自动重试，返回 Device 对象或 None"""
    for attempt in range(retries):
        print("[miIO] handshake... (attempt %d/%d)" % (attempt + 1, retries))
        dev = umiiio.Device(plug_ip, plug_token, timeout=5)
        try:
            device_id, stamp = dev.handshake()
            print("[miIO] OK, device_id=%s, stamp=%d" % (device_id.hex(), stamp))
            return dev
        except Exception as e:
            print("[miIO] handshake failed: %s" % e)
            time.sleep(3)
    print("[miIO] all handshake retries failed")
    return None


def main():
    try:
        import config
    except ImportError:
        print("[ERR] config.py not found, deploy first")
        return

    print("ECM50-A07 Smart Plug Reader (miIO + MQTT)")
    print("-" * 50)
    print("Plug IP  : %s" % config.PLUG_IP)
    print("Token    : %s...%s" % (config.PLUG_TOKEN[:4], config.PLUG_TOKEN[-4:]))
    print("MQTT     : %s:%s" % (config.MQTT_BROKER, config.MQTT_PORT))
    print("Dev ID   : %s" % config.MQTT_DEVICE_ID)
    print()

    # 1) WiFi - 失败则重启设备
    ip = connect_wifi(config.WIFI_SSID, config.WIFI_PASSWORD)
    if not ip:
        print("[FAIL] WiFi connect failed, rebooting in 10s...")
        time.sleep(10)
        machine.reset()
    gc.collect()

    # 2) miIO 握手 - 失败则重启设备
    dev = miio_handshake(config.PLUG_IP, config.PLUG_TOKEN, retries=3)
    if dev is None:
        print("[FAIL] miIO handshake failed, rebooting in 10s...")
        time.sleep(10)
        machine.reset()
    print()

    # 3) MQTT 连接
    print("[MQTT] connecting...")
    dev_id = config.MQTT_DEVICE_ID
    topic_data = "ecm50/%s/data" % dev_id
    topic_cmd = "ecm50/%s/cmd" % dev_id
    topic_resp = "ecm50/%s/resp" % dev_id
    print("[MQTT] pub topic :", topic_data)
    print("[MQTT] sub topic :", topic_cmd)

    cmd_buffer = []

    def on_mqtt_msg(topic, msg):
        try:
            t = topic.decode()
            m = msg.decode()
        except Exception:
            return
        print("[MQTT RECV] %s" % m)
        try:
            cmd_obj = json.loads(m)
            cmd_buffer.append(cmd_obj)
        except Exception as e:
            print("[MQTT] parse err: %s" % e)

    mqtt_client = MQTTClient(
        client_id="ecm50_%s" % dev_id,
        server=config.MQTT_BROKER,
        port=config.MQTT_PORT,
        user=config.MQTT_USER or None,
        password=config.MQTT_PASSWORD or None,
    )
    mqtt_client.set_callback(on_mqtt_msg)
    try:
        mqtt_client.connect()
    except Exception as e:
        print("[MQTT] connect FAIL: %s" % e)
        print("Continuing without MQTT (serial output only)")
        mqtt_client = None
    else:
        print("[MQTT] connected")
        mqtt_client.subscribe(topic_cmd)
        print("[MQTT] subscribed:", topic_cmd)
    print()

    gc.collect()

    # 4) 主循环
    seq = 0
    print("Monitor mode (5s interval, auto-reconnect on failure)")
    print("-" * 50)

    wifi_sta = network.WLAN(network.STA_IF)

    while True:
        try:
            # WiFi 断线检测 + 自动重连
            if not wifi_sta.isconnected():
                print("[WiFi] disconnected, reconnecting...")
                ip = connect_wifi(config.WIFI_SSID, config.WIFI_PASSWORD, retries=5)
                if ip is None:
                    print("[WiFi] reconnect failed, rebooting in 10s...")
                    time.sleep(10)
                    machine.reset()
                # WiFi 恢复后重新 miIO 握手
                dev = miio_handshake(config.PLUG_IP, config.PLUG_TOKEN, retries=3)
                if dev is None:
                    print("[miIO] re-handshake failed, rebooting in 10s...")
                    time.sleep(10)
                    machine.reset()
                # 重新连接 MQTT
                if mqtt_client is not None:
                    try:
                        mqtt_client.connect()
                        mqtt_client.subscribe(topic_cmd)
                        print("[MQTT] reconnected")
                    except Exception as e:
                        print("[MQTT] reconnect failed: %s" % e)
                        mqtt_client = None
                continue

            # 处理 MQTT 指令
            if mqtt_client is not None:
                mqtt_client.check_msg()
                while cmd_buffer:
                    cmd_obj = cmd_buffer.pop(0)
                    resp = handle_cmd(cmd_obj, dev)
                    resp_str = json.dumps(resp)
                    mqtt_client.publish(topic_resp, resp_str)
                    print("[MQTT PUB RESP] %s" % resp_str)

            # 读取所有属性
            data = read_all_props(dev)
            print_data(data)

            # 发布到 MQTT
            if mqtt_client is not None:
                payload = build_payload(data, dev_id, seq)
                payload_str = json.dumps(payload)
                mqtt_client.publish(topic_data, payload_str)
                print("[MQTT PUB] seq=%d" % seq)

            seq += 1

            ts = time.localtime()
            tstr = "%02d:%02d:%02d" % (ts[3], ts[4], ts[5])
            power = data.get("power")
            temp = data.get("temperature")
            print("[%s] Power: %6.2f W | Temp: %s C" %
                  (tstr, float(power or 0), temp))
            print()
        except Exception as e:
            print("[ERR] %s" % e)
        time.sleep(5)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped")
    except Exception as e:
        print("[FATAL] %s" % e)
        print("Rebooting in 10s...")
        time.sleep(10)
        machine.reset()
