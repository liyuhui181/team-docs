"""
ECM50-A07 主程序（miIO 数据采集 + 涂鸦云 TuyaLink 上报）

工作流程：
1. 连接 WiFi
2. 连接涂鸦云 MQTT (m1.tuyacn.com:8883, TuyaLink 协议)
3. 与米家智能插座握手 (miIO 协议)
4. 主循环：每 5 秒读取插座数据 -> 上报涂鸦云
5. 监听云端指令 (property/set)

上电自启: MicroPython 自动执行 boot.py -> main.py
断电恢复: WiFi/MQTT/miIO 任一断线自动重连，超限则重启设备
"""

import time
import network
import gc
import json
import machine
import hashlib
from umqtt.simple import MQTTClient

import umiiio


# ===== 涂鸦云设备凭证 =====
PRODUCT_ID = "deihosbfawqqi8ac"
DEVICE_ID = "263c9d32705d72a956qrgj"
DEVICE_SECRET = "SnZ9FfQ3zZODjr6e"
MQTT_BROKER = "m1.tuyacn.com"
MQTT_PORT = 8883

# NTP 服务器
NTP_HOST = "pool.ntp.org"

# ===== 米家智能插座3 (cuco.plug.v3) 属性映射 =====
SOCKET_PROPERTIES = [
    ("switch", 2, 1, "Switch", "bool"),
    ("fault", 2, 3, "Fault", "uint8"),
    ("power", 11, 2, "Power", "float"),
    ("power_consumed", 11, 1, "Energy", "uint16(0.01kWh)"),
    ("on_off_count", 12, 1, "Count", "uint8"),
    ("temperature", 12, 2, "Temp", "uint8"),
    ("indicator_light", 13, 1, "LED", "bool"),
]


def sync_ntp():
    """NTP 时间同步，涂鸦云校验 timestamp 必须先同步时钟"""
    try:
        import ntptime
        ntptime.host = NTP_HOST
        ntptime.timeout = 10
        print("[NTP] syncing...")
        ntptime.settime()
        print("[NTP] OK, time=%d" % int(time.time()))
        return True
    except Exception as e:
        print("[NTP] failed: %s" % e)
        return False


def hmac_sha256(key, msg):
    """用 hashlib 手动实现 HMAC-SHA256 (MicroPython 无 hmac 模块)"""
    block_size = 64
    if len(key) > block_size:
        key = hashlib.sha256(key).digest()
    key = key + b'\x00' * (block_size - len(key))

    ipad = bytes(b ^ 0x36 for b in key)
    opad = bytes(b ^ 0x5c for b in key)

    inner = hashlib.sha256(ipad + msg).digest()
    outer = hashlib.sha256(opad + inner).digest()
    return outer.hex()


def generate_tuya_credentials():
    """生成涂鸦 MQTT 连接三元组"""
    timestamp = str(int(time.time()))
    client_id = "tuyalink_%s" % DEVICE_ID
    username = "%s|signMethod=hmacSha256,timestamp=%s,secureMode=1,accessType=1" % (DEVICE_ID, timestamp)
    content = "deviceId=%s,timestamp=%s,secureMode=1,accessType=1" % (DEVICE_ID, timestamp)
    password = hmac_sha256(DEVICE_SECRET.encode("utf-8"), content.encode("utf-8"))
    while len(password) < 64:
        password = '0' + password
    return client_id, username, password


# ===== 涂鸦 TuyaLink Topic =====
def topic_property_report():
    return "tylink/%s/thing/property/report" % DEVICE_ID

def topic_property_set():
    return "tylink/%s/thing/property/set" % DEVICE_ID


def build_tuya_payload(properties):
    """构建涂鸦属性上报 JSON"""
    ts = int(time.time() * 1000)
    data = {}
    for key, value in properties.items():
        data[key] = {"value": value, "time": ts}
    return json.dumps({"data": data})


def on_tuya_msg(topic, msg):
    """涂鸦云端消息回调"""
    topic_str = topic.decode() if isinstance(topic, bytes) else topic
    msg_str = msg.decode() if isinstance(msg, bytes) else msg
    print("[Tuya RECV] %s" % msg_str)


def connect_wifi(ssid, password, timeout=20, retries=3):
    """连接 WiFi，失败自动重试"""
    sta = network.WLAN(network.STA_IF)

    for attempt in range(retries):
        if not sta.active():
            sta.active(True)
            time.sleep(2)
        if sta.isconnected():
            return sta

        print("[WiFi] connecting: %s (attempt %d/%d)" % (ssid, attempt + 1, retries))
        sta.connect(ssid, password)

        t0 = time.time()
        while not sta.isconnected():
            if time.time() - t0 > timeout:
                print("[WiFi] timeout")
                break
            time.sleep(0.5)

        if sta.isconnected():
            print("[WiFi] OK, IP=%s" % sta.ifconfig()[0])
            return sta

        sta.active(False)
        time.sleep(1)

    print("[WiFi] all retries failed")
    return None


def connect_tuya_mqtt():
    """连接涂鸦云 MQTT，返回 MQTTClient 或 None"""
    client_id, username, password = generate_tuya_credentials()
    print("[Tuya] connecting to %s:%d..." % (MQTT_BROKER, MQTT_PORT))

    mqtt = MQTTClient(
        client_id=client_id,
        server=MQTT_BROKER,
        port=MQTT_PORT,
        user=username,
        password=password,
        keepalive=60,
        ssl=True,
        ssl_params={},
    )
    mqtt.set_callback(on_tuya_msg)

    try:
        mqtt.connect()
        print("[Tuya] connected!")
        mqtt.subscribe(topic_property_set())
        print("[Tuya] subscribed: %s" % topic_property_set())

        # 上报设备物模型 (涂鸦云要求)
        model_topic = "tylink/%s/thing/model/get" % DEVICE_ID
        model_payload = '{"data":{"properties":[{"code":"ECM50A_online","mode":"r"},{"code":"cold_storage_temp","mode":"r"},{"code":"cold_storage_run_mode","mode":"rw"}]}}'
        mqtt.publish(model_topic, model_payload)
        print("[Tuya] model reported")

        # 上报上线状态
        payload = build_tuya_payload({"ECM50A_online": True})
        mqtt.publish(topic_property_report(), payload)
        print("[Tuya] reported online: %s" % payload)
        return mqtt
    except Exception as e:
        print("[Tuya] connect FAIL: %s" % e)
        return None


def miio_handshake(plug_ip, plug_token, retries=3):
    """miIO 握手，失败自动重试"""
    for attempt in range(retries):
        print("[miIO] handshake... (attempt %d/%d)" % (attempt + 1, retries))
        dev = umiiio.Device(plug_ip, plug_token, timeout=5)
        try:
            device_id, stamp = dev.handshake()
            print("[miIO] OK, device_id=%s, stamp=%d" % (device_id.hex(), stamp))
            return dev
        except Exception as e:
            print("[miIO] handshake failed: %s" % e)
            time.sleep(3)
    print("[miIO] all handshake retries failed")
    return None


def read_all_props(dev):
    """批量读取所有属性"""
    req = [{"siid": p[1], "piid": p[2]} for p in SOCKET_PROPERTIES]
    results = dev.get_properties(req)
    out = {}
    if isinstance(results, list):
        for i, (key, siid, piid, name, _type) in enumerate(SOCKET_PROPERTIES):
            value = None
            if i < len(results):
                item = results[i]
                if isinstance(item, dict) and item.get("code", -1) == 0:
                    value = item.get("value")
            out[key] = value
    return out


def main():
    try:
        import config
    except ImportError:
        print("[ERR] config.py not found")
        return

    print("=" * 50)
    print("  ECM50-A07 -> Tuya Cloud")
    print("  Device ID: %s" % DEVICE_ID)
    print("=" * 50)

    # 1) WiFi
    wlan = connect_wifi(config.WIFI_SSID, config.WIFI_PASSWORD)
    if wlan is None:
        print("[FAIL] WiFi, rebooting in 10s...")
        time.sleep(10)
        machine.reset()
    gc.collect()

    # 1.5) NTP 时间同步 (涂鸦云校验 timestamp)
    sync_ntp()
    gc.collect()

    # 2) 涂鸦云 MQTT
    mqtt = connect_tuya_mqtt()
    if mqtt is None:
        print("[FAIL] Tuya MQTT, rebooting in 10s...")
        time.sleep(10)
        machine.reset()
    gc.collect()

    # 3) miIO 握手
    dev = miio_handshake(config.PLUG_IP, config.PLUG_TOKEN)
    if dev is None:
        print("[WARN] miIO failed, continuing with Tuya cloud only")

    print()
    print("Monitor mode (5s interval, auto-reconnect)")
    print("-" * 50)

    seq = 0
    tick = 0
    while True:
        try:
            # WiFi 断线检测
            if not wlan.isconnected():
                print("[WiFi] disconnected, reconnecting...")
                wlan = connect_wifi(config.WIFI_SSID, config.WIFI_PASSWORD, retries=5)
                if wlan is None:
                    print("[WiFi] failed, rebooting in 10s...")
                    time.sleep(10)
                    machine.reset()
                mqtt = connect_tuya_mqtt()
                if mqtt is None:
                    print("[Tuya] reconnect failed, rebooting in 10s...")
                    time.sleep(10)
                    machine.reset()
                dev = miio_handshake(config.PLUG_IP, config.PLUG_TOKEN)
                tick = 0
                continue

            # 每 15 秒: 发 ping 维持心跳
            tick += 1
            if tick >= 15:
                tick = 0
                mqtt.ping()
                print("[Tuya] ping sent")
                # 读取数据 + 上报
                if dev is not None:
                    data = read_all_props(dev)
                    power = data.get("power")
                    temp = data.get("temperature")
                    switch = data.get("switch")
                    ts = time.localtime()
                    tstr = "%02d:%02d:%02d" % (ts[3], ts[4], ts[5])
                    print("[%s] P=%6.2fW T=%s Sw=%s" % (tstr, float(power or 0), temp, switch))

                    tuya_props = {"ECM50A_online": True}
                    if power is not None:
                        tuya_props["cold_storage_temp"] = float(temp) if temp is not None else 0
                        tuya_props["cold_storage_run_mode"] = 1 if switch else 0

                    payload = build_tuya_payload(tuya_props)
                    mqtt.publish(topic_property_report(), payload)
                    print("[Tuya] reported seq=%d" % seq)
                else:
                    payload = build_tuya_payload({"ECM50A_online": True})
                    mqtt.publish(topic_property_report(), payload)
                    print("[Tuya] heartbeat seq=%d" % seq)

                seq += 1

        except OSError as e:
            print("[MQTT err] %s, reconnecting..." % e)
            time.sleep(3)
            try:
                mqtt = connect_tuya_mqtt()
                if mqtt is None:
                    print("[Tuya] reconnect failed, retry in 5s")
                    time.sleep(5)
                tick = 0
            except Exception as e2:
                print("[Tuya] reconnect error: %s" % e2)
                time.sleep(5)

        except Exception as e:
            print("[ERR] %s" % e)

        time.sleep(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped")
    except Exception as e:
        print("[FATAL] %s" % e)
        print("Rebooting in 10s...")
        time.sleep(10)
        machine.reset()
