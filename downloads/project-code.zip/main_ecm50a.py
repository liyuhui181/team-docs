"""
ECM50-A 开机自启入口文件

此文件由 MicroPython 在 boot.py 之后自动执行。
上电后自动运行 ecm50a_tuya_main.py 中的 main() 函数。

如果主程序异常退出，等待 10 秒后自动重启设备。
"""

import time
import machine
import ecm50a_tuya_main

try:
    ecm50a_tuya_main.main()
except Exception as e:
    print(f"[main] 程序异常退出: {e}")
    print("[main] 10 秒后自动重启设备...")
    time.sleep(10)
    machine.reset()
