"""
ECM50-A 开机引导文件

MicroPython 启动顺序:
    1. boot.py (本文件) - 最先执行，负责基础初始化
    2. main.py - 随后执行，调用主程序

此文件在设备上电/复位时自动执行，无需手动运行。
将 boot.py 和 main.py 一起上传到 ECM50-A 即可实现上电自启。
"""

import machine
import time

print("[boot] ECM50-A starting...")

# 短暂延时，等待硬件就绪
time.sleep(0.5)

# 检查复位原因
reason = machine.reset_cause()
if reason == 1:
    print("[boot] Reset reason: Power on (cold start)")
elif reason == 2:
    print("[boot] Reset reason: Hard reset (external reset)")
elif reason == 3:
    print("[boot] Reset reason: WDT reset (watchdog)")
elif reason == 4:
    print("[boot] Reset reason: Soft reset")
else:
    print(f"[boot] Reset reason: {reason}")

print("[boot] boot.py done, starting main.py...")
